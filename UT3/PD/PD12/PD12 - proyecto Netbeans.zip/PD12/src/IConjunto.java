
/**
 *
 * @author ernesto
 * @param <T>
 */
public interface IConjunto {

    
    public Conjunto union (Conjunto otroConjunto);

    public Conjunto interseccion (Conjunto otroConjunto);
}
